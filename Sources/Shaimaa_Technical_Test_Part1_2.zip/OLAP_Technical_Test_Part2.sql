IF OBJECT_ID(N'FactClientCampaignPlan' , 'table') IS NOT NULL 
	DROP TABLE FactClientCampaignPlan;
GO
----------------DimPublisherNetwork Dimension --------------
IF OBJECT_ID(N'DimPublisherNetwork' , 'table') IS NOT NULL 
	DROP TABLE DimPublisherNetwork;
GO
----------------DiimMediaNameCategory Dimension --------------
IF OBJECT_ID(N'DimMediaNameCategory' , 'table') IS NOT NULL 
	DROP TABLE DimMediaNameCategory;
GO
----------------DimMediaGroup Dimension --------------
IF OBJECT_ID(N'DimMediaGroup' , 'table') IS NOT NULL 
	DROP TABLE DimMediaGroup;
GO
IF OBJECT_ID(N'DimEmployeeRole' , 'table') IS NOT NULL 
	DROP TABLE DimEmployeeRole;
GO
IF OBJECT_ID(N'DimEmployee' , 'table') IS NOT NULL 
	DROP TABLE DimEmployee;
GO
----------------DimPaymentPlan Dimension --------------
IF OBJECT_ID(N'DimPaymentPlan' , 'table') IS NOT NULL 
	DROP TABLE DimPaymentPlan;
GO
----------------DimBuyingOption  Dimension --------------
IF OBJECT_ID(N'DimBuyingOption' , 'table') IS NOT NULL 
	DROP TABLE DimBuyingOption;
GO
----------------DimCampaignLanguage  Dimension --------------
IF OBJECT_ID(N'DimCampaignLanguage' , 'table') IS NOT NULL 
	DROP TABLE DimCampaignLanguage;
GO

-----------------ClientCampaign Dimension --------------

IF OBJECT_ID(N'DimClientCampaign' , 'table') IS NOT NULL 
	DROP TABLE DimClientCampaign;
GO

----------------------------------------------------------------------------------------------
----------------DimCreative Size  Dimension ----------
IF OBJECT_ID(N'DimCreativeSize' , 'table') IS NOT NULL 
	DROP TABLE DimCreativeSize;
GO
-----------------DimProduct Dimension --------------
IF OBJECT_ID(N'DimProduct' , 'table') IS NOT NULL 
	DROP TABLE DimProduct;
GO

-----------------DimLineOfBusiness Dimension --------
IF OBJECT_ID(N'DimLineOfBusiness' , 'table') IS NOT NULL 
	DROP TABLE DimLineOfBusiness;
GO
-----------------DimClient Dimension-----------------
IF OBJECT_ID(N'DimClient' , 'table') IS NOT NULL 
	DROP TABLE DimClient;
GO
---------------DimLocation Dimension----------------
IF OBJECT_ID(N'DimLocation' , 'table') IS NOT NULL 
	DROP TABLE DimLocation;
GO
---------------------------------------------------------------------------------------------------------
----------------DimArea Dimension------------------
IF OBJECT_ID(N'DimArea' , 'table') IS NOT NULL 
	DROP TABLE DimArea;
GO

----------------DimCountry Dimension-----------------
IF OBJECT_ID(N'DimCountry' , 'table') IS NOT NULL 
	DROP TABLE DimCountry;
GO

----------------DimRegion Dimension-------------------
IF OBJECT_ID(N'DimRegion' , 'table') IS NOT NULL 
	DROP TABLE DimRegion;
GO
--------------------Continent Table-----------------------
IF OBJECT_ID(N'DimContinent' , 'table') IS NOT NULL 
	DROP TABLE DimContinent;
GO
/***************************************************************/
/*---------------------Create Dimensions----------------------*/
---------------------------------------------------------------
/**************************************************************/
------------------------------------------------------------------------------------
CREATE TABLE DimContinent (
	ContinentID INT IDENTITY NOT NULL,
	ContinentName VARCHAR(25),
	CONSTRAINT  PK_DimContinent  PRIMARY KEY(ContinentID)
);
Go

INSERT INTO DimContinent
SELECT ContinentName
FROM Continent
WHERE ContinentName  NOT IN (select ContinentName from DimContinent);
GO

CREATE TABLE DimRegion (
	RegionID INT IDENTITY NOT NULL,
	RegionName VARCHAR(25),
	ContinentID int,
	CONSTRAINT  PK_DimRegion  PRIMARY KEY(RegionID),
	CONSTRAINT  FK_DimRegion_DimContinent FOREIGN KEY(ContinentID) REFERENCES DimContinent(ContinentID)
);
Go
INSERT INTO DimRegion
SELECT RegionName,ContinentID
FROM Region
WHERE RegionName  NOT IN (select RegionName from DimRegion);
GO

CREATE TABLE DimCountry (
	CountryID INT IDENTITY NOT NULL,
	CountryName VARCHAR(150),
	RegionID int,
	CONSTRAINT  PK_DimCountry  PRIMARY KEY(CountryID),
	CONSTRAINT  FK_DimCountry_DimRegion FOREIGN KEY(RegionID) REFERENCES DimRegion(RegionID)
);
Go
INSERT INTO DimCountry
SELECT CountryName,RegionID
FROM Country
WHERE CountryName  NOT IN (select CountryName from DimCountry);
GO

CREATE TABLE DimArea (
	AreaID INT IDENTITY NOT NULL,
	AreaName VARCHAR(25),
	CountryID int,
	CONSTRAINT  PK_DimArea  PRIMARY KEY(AreaID),
	CONSTRAINT  FK_DimArea_DimCountry  FOREIGN KEY(CountryID) REFERENCES DimCountry(CountryID)
);
Go

INSERT INTO DimArea
SELECT AreaName,CountryID
FROM Area
WHERE AreaName  NOT IN (select AreaName from DimArea);
GO
CREATE TABLE DimLocation (
	LocationID INT IDENTITY NOT NULL ,
	LocationName VARCHAR(25),
	AreaNaMe VARCHAR(25),
	CountryName VARCHAR(150),
	RegionName VARCHAR(25),
	ContinentName VARCHAR(25),
	AreaID int,
	CONSTRAINT PK_DimLocation PRIMARY KEY(LocationID),
	CONSTRAINT  FK_DimLocation_DimArea  FOREIGN KEY(AreaID) REFERENCES DimArea(AreaID)
);
Go

DELETE FROM DimLocation;
GO

INSERT INTO DimLocation
SELECT LocationName, AreaName, CountryName,
	   RegionName, ContinentName,Area.AreaID 
FROM Location
JOIN Area ON Area.AreaID = Location.AreaID
JOIN Country ON Country.CountryID = Area.CountryID
JOIN Region ON Region.RegionID = Country.RegionID
JOIN Continent ON Continent.ContinentID = Region.ContinentID;

GO
--------------------------------------------------------------
CREATE TABLE DimMediaGroup(
	MediaGroupID int identity ,
	MediaGroupName VARCHAR(50),
	CONSTRAINT PK_DimMediaGroup PRIMARY KEY(MediaGroupID)
);
Go

INSERT INTO DimMediaGroup(MediaGroupName)
SELECT	MediaGroupName 
FROM	MediaGroup
WHERE	MediaGroupName 
		NOT IN (SELECT MediaGroupName from DimMediaGroup);

GO
--------------------------------------------------------------

CREATE TABLE DimMediaNameCategory(
	MediaNameID int identity ,
	MediaNameCategory VARCHAR(50),
	MediaGroupID int,
	CONSTRAINT PK_DimMediaNameCategory PRIMARY KEY(MediaNameID),
	CONSTRAINT  FK_DimMediaNameCategory_DimMediaGroup  FOREIGN KEY(MediaGroupID) REFERENCES DimMediaGroup(MediaGroupID)
);

INSERT INTO DimMediaNameCategory(MediaNameCategory,MediaGroupID)
SELECT	MediaNameCategory , MediaGroupID
FROM	MediaNameCategory
WHERE	MediaNameCategory 
		NOT IN (SELECT MediaNameCategory from DimMediaNameCategory);

GO
-------------------------------------------------------------
CREATE TABLE DimPublisherNetwork(
	PublisherID int identity ,
	PublisherName VARCHAR(255),
	MediaNameID int,
	CONSTRAINT PK_DimPublisherNetwork PRIMARY KEY(PublisherID),
	CONSTRAINT  FK_DimPublisherNetwork_DimMediaNameCategory  FOREIGN KEY(MediaNameID) REFERENCES DimMediaNameCategory(MediaNameID)
);

Go
INSERT INTO DimPublisherNetwork(PublisherName,MediaNameID)
SELECT	PublisherName,MediaNameID
FROM	PublisherNetwork
WHERE	PublisherName 
		NOT IN (SELECT PublisherName from DimPublisherNetwork);

GO
--------------------------------------------------------------

CREATE TABLE DimPaymentPlan(
	PaymentPlanID int identity ,
	PaymentPlanName VARCHAR(50),
	CONSTRAINT PK_DimPaymentPlan PRIMARY KEY(PaymentPlanID)
);
Go

INSERT INTO DimPaymentPlan(PaymentPlanName)
SELECT	PaymentPlanName
FROM	PaymentPlan
WHERE	PaymentPlanName 
		NOT IN (SELECT PaymentPlanName from DimPaymentPlan);

--------------------------------------------------------------

CREATE TABLE DimBuyingOption(
	BuyingOptionID int identity,
	BuyingOptionName VARCHAR(50),
	CONSTRAINT PK_DimBuyingOption PRIMARY KEY(BuyingOptionID)
);

Go

INSERT INTO DimBuyingOption(BuyingOptionName)
SELECT	BuyingOptionName
FROM	BuyingOption
WHERE	BuyingOptionName 
		NOT IN (SELECT BuyingOptionName from DimBuyingOption);

--------------------------------------------------------------

CREATE TABLE DimEmployee(
	EmployeeID int identity,
	EmployeeName VARCHAR(50),
	CONSTRAINT PK_DimEmployee PRIMARY KEY(EmployeeID)
);
Go

INSERT INTO DimEmployee(EmployeeName)
SELECT	EmployeeName
FROM	Employee
WHERE	EmployeeName 
		NOT IN (SELECT EmployeeName from DimEmployee);
---------------------------------------------------------------
CREATE TABLE DimEmployeeRole(
	EmployeeRoleID int Identity,
	EmployeeRoleName  VARCHAR(50),
	EmployeeID int,
	EmployeeRoleStartDate datetime,
	EmployeeRoleEndDate datetime,
	CONSTRAINT PK_DimEmployeeRole PRIMARY KEY(EmployeeRoleID),
	CONSTRAINT  FK_DimEmployeeRole_DimEmployee FOREIGN KEY(EmployeeID) REFERENCES DimEmployee(EmployeeID)
);
Go
IF OBJECT_ID(N'dbo.getDimEmployeeID' , 'function') IS NOT NULL 
	DROP FUNCTION getDimEmployeeID;
GO
CREATE FUNCTION getDimEmployeeID(@EmployeeName VARCHAR(255))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = EmployeeID from DimEmployee where EmployeeName = @EmployeeName;
	return @ID;
END

GO
;with DimEmployeeRoles as
(
SELECT	EmployeeID = dbo.getDimEmployeeID(EmployeeName),EmployeeRoleName,EmployeeRoleStartDate,EmployeeRoleEndDate
FROM	EmployeeRole
join Employee on employee.EmployeeID = EmployeeRole.EmployeeID
)
INSERT INTO DimEmployeeRole(EmployeeID,EmployeeRoleName,EmployeeRoleStartDate,EmployeeRoleEndDate)
SELECT EmployeeID,EmployeeRoleName,EmployeeRoleStartDate,EmployeeRoleEndDate 
FROM DimEmployeeRoles ers
WHERE isnull ((
		select 1 from DimEmployeeRole er 
		where  isnull(ers.EmployeeID,'') = isnull(er.EmployeeID,'')
			and	isnull(ers.EmployeeRoleStartDate,'') = isnull(er.EmployeeRoleStartDate,'')
			and isnull(ers.EmployeeRoleEndDate,'') = isnull(er.EmployeeRoleEndDate,'')
			and isnull(ers.EmployeeRoleName,'') = isnull(er.EmployeeRoleName,'') ) ,0) = 0 
GO 


---------------------------------------------------------------
CREATE TABLE DimCampaignLanguage(
	LanguageID int IDENTITY ,
	LanguageName varchar(50),
	CONSTRAINT PK_DimCampaignLanguage PRIMARY KEY(LanguageID)
);
GO 

INSERT INTO DimCampaignLanguage (LanguageName)
SELECT LanguageName
FROM CampaignLanguage
WHERE LanguageName NOT IN (SELECT LanguageName FROM DimCampaignLanguage)

GO

---------------------------------------------------------------

CREATE TABLE DimCreativeSize(
	CreativeSizeID int IDENTITY,
	CreativeSizeDescription varchar(50),
	CONSTRAINT PK_DimCreativeSize PRIMARY KEY(CreativeSizeID)
);

GO 

INSERT INTO DimCreativeSize (CreativeSizeDescription)
SELECT CreativeSizeDescription
FROM CreativeSize
WHERE CreativeSizeDescription NOT IN (SELECT CreativeSizeDescription FROM DimCreativeSize)

GO
---------------------------------------------------------------
CREATE TABLE DimLineOfBusiness(
	LOBID char(3) ,
	LOBDescription VARCHAR(100),
	CONSTRAINT PK_DimLineOfBusiness PRIMARY KEY(LOBID)
);
GO
INSERT INTO DimLineOfBusiness (LOBID, LOBDescription)
SELECT LOBID, LOBDescription
FROM LineOfBusiness
WHERE LOBID NOT IN (SELECT LOBID FROM DimLineOfBusiness)

GO
----------------------------------------------------------------
CREATE TABLE DimProduct(
	ProductID int identity ,
	ProductCode Char(10),
	ProductDescription VARCHAR(255),
	CONSTRAINT PK_DimProduct PRIMARY KEY(ProductID)
);

Go

INSERT INTO DimProduct (ProductCode, ProductDescription)
SELECT ProductCode, ProductDescription
FROM Product
WHERE ProductCode NOT IN (SELECT ProductCode FROM DimProduct)

GO
--------------------------------------------------------

 CREATE TABLE DimClient(
	ClientID int,
	ClientCode VARCHAR(255),
	ClientContactName VARCHAR(100),
	ClientLocationID int,
	CONSTRAINT  PK_DimClient  PRIMARY KEY(ClientID),
	CONSTRAINT  FK_DimClient_DimLocation  FOREIGN KEY(ClientLocationID) REFERENCES DimLocation(LocationID)
);


GO

INSERT INTO DimCLient(ClientID,ClientCode,ClientContactName,ClientLocationID)
SELECT ClientID,ClientCode,ClientContactName,ClientLocationID 
FROM CLient
WHERE ClientID NOT IN (SELECT ClientID FROM DimCLient)	

GO
-------------------------------------------------------------------------------------------------------
 CREATE TABLE DimClientCampaign(
	ClientCampaignID int Identity ,
	ClientCampaignName VARCHAR(255),
	StartDate datetime,
	NumberOfWeeks smallint,
	CONSTRAINT  PK_DimClientCampaign  PRIMARY KEY(ClientCampaignID)
);
GO


INSERT INTO DimClientCampaign(ClientCampaignName,StartDate,NumberOfWeeks)
SELECT ClientCampaignName,StartDate,NumberOfWeeks 
FROM ClientCampaign
WHERE ClientCampaignName NOT IN (SELECT ClientCampaignName FROM DimClientCampaign)	

GO

--------------------------------------------------------------------------------------------------------

-------------------FactClientCampaignPlan FactTable ----------------------

 CREATE TABLE FactClientCampaignPlan(
	ClientCampaignPlanID int Identity ,
	ClientCampaignPlaneDescription VARCHAR(255),
	ClientCampaignID int,
	WeekNumber smallint,
	StratDate datetime,
	EndDate datetime,
	iYear smallint,
	PublisherID int,
	LanguageID int,
	MediaGroupID int,
	MediaNameID int,
	ManagerEmployeeID int,
	ProductID int,
	ClientID int,
	BuyerEmployeeID int,
	LOBID char(3),
	LocationID int,
	BuyingOptionID int,
	PaymentPlanID int,
	CreativeSizeID int,
	Creative varchar(256),
	Placement  varchar(256),
	PlannedAds int,
	RunAds int,
	PlannedSpend float,
	ActualSpend float,
	Impressions int,
	Clickes int,
	CPM float,
	CPC float,
	CTR float,
	Reach int,
	CPR float,
	Frequency float,
	Swipes int,
	Calls float,
	Responses float,
	BounceRate float,
	GPAConversion float,
	CONSTRAINT  PK_DimClientCampaignPlan  PRIMARY KEY(ClientCampaignPlanID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimClientCampaignID  FOREIGN KEY(ClientCampaignID) REFERENCES DimClientCampaign(ClientCampaignID),	
	CONSTRAINT  FK_DimClientCampaignPlan_DimPublisherNetwork  FOREIGN KEY(PublisherID) REFERENCES DimPublisherNetwork(PublisherID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimLanguage  FOREIGN KEY(LanguageID) REFERENCES DimCampaignLanguage(LanguageID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimBuyerEmployee  FOREIGN KEY(BuyerEmployeeID) REFERENCES DimEmployee(EmployeeID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimManagerEmployee  FOREIGN KEY(ManagerEmployeeID) REFERENCES DimEmployee(EmployeeID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimProduct  FOREIGN KEY(ProductID) REFERENCES DimProduct(ProductID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimClient  FOREIGN KEY(ClientID) REFERENCES DimClient(ClientID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimMediaGroup  FOREIGN KEY(MediaGroupID) REFERENCES DimMediaGroup(MediaGroupID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimMediaName  FOREIGN KEY(MediaNameID) REFERENCES DimMediaNameCategory(MediaNameID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimLineOfBusiness  FOREIGN KEY(LOBID) REFERENCES DimLineOfBusiness(LOBID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimLocation  FOREIGN KEY(LocationID) REFERENCES DimLocation(LocationID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimBuyingOption  FOREIGN KEY(BuyingOptionID) REFERENCES DimBuyingOption(BuyingOptionID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimPaymentPlan  FOREIGN KEY(PaymentPlanID) REFERENCES DimPaymentPlan(PaymentPlanID),
	CONSTRAINT  FK_DimClientCampaignPlan_DimCreativeSize  FOREIGN KEY(CreativeSizeID) REFERENCES DimCreativeSize(CreativeSizeID)
);
GO


