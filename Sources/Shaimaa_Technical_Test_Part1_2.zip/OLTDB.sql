
----------------MediaGroup Table --------------
IF OBJECT_ID(N'MediaGroup' , 'table') IS NOT NULL 
	DROP TABLE MediaTypeGroup;
GO
----------------MediaNameCategory Table --------------
IF OBJECT_ID(N'MediaNameCategory' , 'table') IS NOT NULL 
	DROP TABLE MediaNameCategory;
GO
----------------MediaPublisherNetwork Table --------------
IF OBJECT_ID(N'PublisherNetwork' , 'table') IS NOT NULL 
	DROP TABLE PublisherNetwork;
GO
----------------Payment Plan Table --------------
IF OBJECT_ID(N'PaymentPlan' , 'table') IS NOT NULL 
	DROP TABLE PaymentPlan;
GO
----------------BuyingOption  Table --------------
IF OBJECT_ID(N'BuyingOption' , 'table') IS NOT NULL 
	DROP TABLE BuyingOption;
GO
----------------CampaignLanguage  Table --------------
IF OBJECT_ID(N'CampaignLanguage' , 'table') IS NOT NULL 
	DROP TABLE CampaignLanguage;
GO
-----------------ClientCampaign Table --------------
IF OBJECT_ID(N'ClientCampaign' , 'table') IS NOT NULL 
	DROP TABLE ClientCampaign;
GO
IF OBJECT_ID(N'CampaignPlane' , 'table') IS NOT NULL 
	DROP TABLE CampaignPlane;
GO
----------------Creative Size  Table --------------
IF OBJECT_ID(N'CreativeSize' , 'table') IS NOT NULL 
	DROP TABLE CreativeSize;
GO
-----------------Product Table --------------
IF OBJECT_ID(N'Product' , 'table') IS NOT NULL 
	DROP TABLE Product;
GO

-----------------Line Of Business Table --------------
IF OBJECT_ID(N'LineOfBusiness' , 'table') IS NOT NULL 
	DROP TABLE LineOfBusiness;
GO
----------------------------------------------------
IF OBJECT_ID(N'Client' , 'table') IS NOT NULL 
	DROP TABLE Client;
GO
------------------------------------------------------
IF OBJECT_ID(N'Location' , 'table') IS NOT NULL 
	DROP TABLE Location;
GO

-------------------------------------------------------
IF OBJECT_ID(N'Area' , 'table') IS NOT NULL 
	DROP TABLE Area;
GO

-------------------------------------------------------
IF OBJECT_ID(N'Country' , 'table') IS NOT NULL 
	DROP TABLE Country;
GO

----------------------Region Table---------------------------------
IF OBJECT_ID(N'Region' , 'table') IS NOT NULL 
	DROP TABLE Region;
GO


--------------------Continent Table-----------------------
IF OBJECT_ID(N'Continent' , 'table') IS NOT NULL 
	DROP TABLE Continent;
GO
CREATE TABLE Continent (
	ContinentID INT IDENTITY NOT NULL PRIMARY KEY,
	ContinentName VARCHAR(25)
);
Go
CREATE TABLE Region (
	RegionID INT IDENTITY NOT NULL PRIMARY KEY,
	RegionName VARCHAR(25),
	ContinentID int,
	CONSTRAINT  FK_Region_Continent FOREIGN KEY(ContinentID) REFERENCES Continent(ContinentID)
);
Go
CREATE TABLE Country (
	CountryID INT IDENTITY NOT NULL PRIMARY KEY,
	CountryName VARCHAR(150),
	RegionID int,
	CONSTRAINT  FK_Country_Region FOREIGN KEY(RegionID) REFERENCES Region(RegionID)
);
Go
CREATE TABLE Area (
	AreaID INT IDENTITY NOT NULL PRIMARY KEY,
	AreaName VARCHAR(25),
	CountryID int,
	CONSTRAINT  FK_Area_Country  FOREIGN KEY(CountryID) REFERENCES Country(CountryID)
);
Go

CREATE TABLE Location (
	LocationID INT IDENTITY NOT NULL PRIMARY KEY,
	LocationName VARCHAR(25),
	AreaID int,
	CONSTRAINT  FK_Location_Area  FOREIGN KEY(AreaID) REFERENCES Area(AreaID)
);
Go
CREATE TABLE LineOfBusiness(
	LOBID char(3) PRIMARY KEY,
	LOBDescription VARCHAR(100)
);
GO
CREATE TABLE Product(
	ProductID int identity Primary KEY,
	ProductCode Char(10),
	ProductDescription VARCHAR(255)
);
Go

CREATE TABLE MediaGroup(
	MediaGroupID int identity PRIMARY KEY,
	MediaGroupName VARCHAR(50)
);
Go
CREATE TABLE MediaNameCategory(
	MediaNameID int identity PRIMARY KEY,
	MediaNameCategory VARCHAR(50),
	MediaGroupID int,
	CONSTRAINT  FK_MediaNameCategory_MediaGroup  FOREIGN KEY(MediaGroupID) REFERENCES MediaGroup(MediaGroupID)
);
Go
CREATE TABLE PublisherNetwork(
	PublisherID int identity PRIMARY KEY,
	PublisherName VARCHAR(255),
	MediaNameID int,
	CONSTRAINT  FK_PublisherNetwork_MediaNameCategory  FOREIGN KEY(MediaNameID) REFERENCES MediaNameCategory(MediaNameID)
);
Go


CREATE TABLE PaymentPlan(
	PaymentPlanID int identity PRIMARY KEY,
	PaymentPlanName VARCHAR(50)
);
Go

CREATE TABLE BuyingOption(
	BuyingOptionID int identity PRIMARY KEY,
	BuyingOptionName VARCHAR(50)
);

Go

CREATE TABLE Employee(
	EmployeeID int identity PRIMARY KEY,
	EmployeeName VARCHAR(50)
);
Go

CREATE TABLE EmployeeRole(
	EmployeeRoleID int Identity PRIMARY KEY,
	EmployeeRoleName  VARCHAR(50),
	EmployeeID int,
	EmployeeRoleStartDate datetime,
	EmployeeRoleEndDate datetime,
	CONSTRAINT  FK_EmployeeRole_Employee FOREIGN KEY(EmployeeID) REFERENCES Employee(EmployeeID)
);
Go

CREATE TABLE CampaignLanguage(
	LanguageID int IDENTITY PRIMARY KEY,
	LanguageName varchar(50)
);
GO 

CREATE TABLE CreativeSize(
	CreativeSizeID int IDENTITY PRIMARY KEY,
	CreativeSizeDescription varchar(50)
);
GO 
-------------------------------------------------
-----------------------------------------------
INSERT INTO  CampaignLanguage (LanguageName)
SELECT distinct  Lang from IPGDataSet 
where Lang not in (select LanguageName from CampaignLanguage);

GO
--------------------------------------------------
INSERT INTO  Employee (EmployeeName)
SELECT distinct  Campaign_Manager from IPGDataSet where Campaign_Manager not in (select EmployeeName from Employee)
union
SELECT distinct  BuyUserName from IPGDataSet 
where BuyUserName not in (select EmployeeName from Employee)
GO
---------------------------------------------------
;with EmployeeRoles as
(
	select s = 'CampaignManager' , EmployeeID , EmployeeRoleStartDate= null , EmployeeRoleEndDate =null
	from IPGDataSet 
	JOIN Employee  ON EmployeeName = Campaign_Manager
union
	select 'BuyUser' , EmployeeID , null , null
	from IPGDataSet 
	JOIN Employee  ON EmployeeName = BuyUserName
)
--INSERT INTO  EmployeeRole (EmployeeRoleName, EmployeeID, EmployeeRoleStartDate, EmployeeRoleEndDate)
select	s , EmployeeID , EmployeeRoleStartDate , EmployeeRoleEndDate
from	EmployeeRoles ers
where (
select 1 from EmployeeRole er 
		where  ers.EmployeeID = er.EmployeeID
			and	isnull(ers.EmployeeRoleStartDate,'') = isnull(er.EmployeeRoleStartDate,'')
			and isnull(ers.EmployeeRoleEndDate,'') = isnull(er.EmployeeRoleEndDate,'')
			and ers.s = er.EmployeeRoleName ) = 0

GO
---------------------------------------------------
INSERT INTO  MediaGroup (MediaGroupName)
SELECT distinct MediaGroup from IPGDataSet 
where MediaGroup not in (select MediaGroupName from MediaGroup)
GO
-------------------------------------------------------
INSERT INTO  MediaNameCategory (MediaNameCategory,MediaGroupID)
SELECT distinct [MediaName] , MediaGroupID
from IPGDataSet 
join MediaGroup  ON MediaGroupName = MediaGroup 
where [MediaName] not in (select MediaNameCategory  from MediaNameCategory)
GO
------------------------------------------------------
;with CreativeSizes as
(
SELECT distinct s = case when charindex('160x600' , Creative,0) > 0  then '160x600' else
				case when charindex('300x250' , Creative,0) > 0  then  '300x250' else 
				case when charindex('728x90', Creative,0) > 0  then '300x250' else
				case when charindex('300x600', Creative,0) > 0  then '300x600' else
				case when charindex('320x50', Creative,0) > 0  then '320x50' else
				case when charindex('1x1', Creative,0) > 0  then '1x1' 
				 end end end end end end
from IPGDataSet 
)
INSERT INTO  CreativeSize (CreativeSizeDescription)
select s from CreativeSizes
where s not in (select CreativeSizeDescription  from CreativeSize)
GO
-------------------------------------------------------
;with Publisher as
(
SELECT distinct s = case when charindex('CPM' , MediaPublisherNetwork,0) > 0  then replace(MediaPublisherNetwork, 'CPM' ,'') else
				case when charindex('CPC' , MediaPublisherNetwork,0) > 0  then replace(MediaPublisherNetwork, 'CPC' ,'') else 
				case when charindex('Flat Rate - Clicks', MediaPublisherNetwork,0) > 0  then replace(MediaPublisherNetwork, 'Flat Rate - Clicks' ,'') else
				case when charindex('Flat Rate - Impressions', MediaPublisherNetwork,0) > 0  then replace(MediaPublisherNetwork, 'Flat Rate - Impressions' ,'') else
				MediaPublisherNetwork end end end end   , MediaNameID
from IPGDataSet 
join MediaNameCategory  ON MediaNameCategory = [MediaName] )
INSERT INTO  PublisherNetwork (PublisherName,MediaNameID)
select s, MediaNameID from Publisher
where s not in (select PublisherName  from PublisherNetwork)
GO
----------------------------------------------------
;with Paymenst as
(SELECT distinct case when charindex('CPM' , MediaPublisherNetwork,0) > 0  then 'CPM'  else
				case when charindex('CPC' , MediaPublisherNetwork,0) > 0  then 'CPC' else 
				case when charindex('Flat Rate - Clicks', MediaPublisherNetwork,0) > 0  then 'Flat Rate - Clicks' else
				case when charindex('Flat Rate - Impressions', MediaPublisherNetwork,0) > 0  then 'Flat Rate - Impressions' end end end end as s 
from IPGDataSet )
INSERT INTO PaymentPlan(PaymentPlanName)
select s from Paymenst where s not in (select PaymentPlanName from PaymentPlan)
GO
----------------------------------------------------
;with BuyingOptions as
(SELECT distinct case when charindex('ROS' , Placement ,0) > 0  then 'ROS'  else
				case when charindex('RON' , Placement ,0) > 0  then 'RON' else 
				case when charindex('ROX' , Placement ,0) > 0  then 'ROX'end end end as s
				from IPGDataSet )
INSERT INTO BuyingOption(BuyingOptionName)
select s from BuyingOptions where s not in (select BuyingOptionName from BuyingOption)
GO
---------------------------------------------------
INSERT INTO  Product (ProductCode,ProductDescription)
SELECT distinct Client_Product , Client_Product 
from IPGDataSet
where Client_Product not in (select ProductCode from  Product)
GO
---------------------------------------------------
INSERT INTO  LineOfBusiness
SELECT distinct Client_LOB , Client_LOB from IPGDataSet

GO
IF OBJECT_ID(N'dbo.getLineOfBusinessID' , 'function') IS NOT NULL 
	DROP FUNCTION getLineOfBusinessID;
GO
CREATE FUNCTION getLineOfBusinessID(@LOBID VARCHAR(50))
RETURNS char(3)
as
BEGIN
	DECLARE @ID int;
	select @ID = LOBID from LineOfBusiness where LOBID = @LOBID;
	return @ID;
END

GO


----------------------------------------------------
INSERT INTO  Continent (ContinentName)
SELECT distinct Client_Continent from IPGDataSet
where Client_Continent not in (select ContinentName from Continent)

Go
IF OBJECT_ID(N'dbo.getContinentID' , 'function') IS NOT NULL 
	DROP FUNCTION getContinentID;
GO
CREATE FUNCTION getContinentID(@ContinentName VARCHAR(25))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = ContinentID from Continent where ContinentName = @ContinentName;
	return @ID;
END
GO
----------------------------------------------------
INSERT INTO  Region (RegionName,ContinentID)
SELECT distinct Client_Region , dbo.getContinentID(Client_Continent) from IPGDataSet 
where Client_Region not in (select RegionName from Region)

Go
IF OBJECT_ID(N'dbo.getRegionID' , 'function') IS NOT NULL 
	DROP FUNCTION getRegionID;
GO
CREATE FUNCTION getRegionID(@RegionName VARCHAR(25))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = RegionID from Region where RegionName = @RegionName;
	return @ID;
END
GO
-------------------------------------------------------
INSERT INTO Country(CountryName,RegionID)
SELECT distinct Client_Country , dbo.getRegionID(Client_Region) from IPGDataSet 
where Client_Country not in (select CountryName from Country)

GO
IF OBJECT_ID(N'dbo.getCountryID' , 'function') IS NOT NULL 
	DROP FUNCTION getCountryID;
GO
CREATE FUNCTION getCountryID(@CountryName VARCHAR(25))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = CountryID from Country where CountryName = @CountryName;
	return @ID;
END
GO
--------------------------------------------------------
INSERT INTO Area(AreaName,CountryID)
SELECT distinct Client_Area , dbo.getCountryID(Client_Country) from IPGDataSet 
where Client_Area not in (select AreaName from Area)

GO
IF OBJECT_ID(N'dbo.getAreaID' , 'function') IS NOT NULL 
	DROP FUNCTION getAreaID;
GO
CREATE FUNCTION getAreaID(@AreaName VARCHAR(25))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = AreaID from Area where AreaName = @AreaName;
	return @ID;
END
GO
---------------------------------------------------------
INSERT INTO Location(LocationName,AreaID)
SELECT distinct Client_Location , dbo.getAreaID(Client_Area) from IPGDataSet 
where Client_Location not in (select LocationName from Location)

GO
IF OBJECT_ID(N'dbo.getLocationID' , 'function') IS NOT NULL 
	DROP FUNCTION getLocationID;
GO
CREATE FUNCTION getLocationID(@ContinentName VARCHAR(25) ,@RegionName VARCHAR(25),@CountryName  VARCHAR(255),@AreaName  VARCHAR(255),@LocationName  VARCHAR(255))
RETURNS int
AS
BEGIN
		DECLARE @ID int;
		select  @ID = l.LocationID 
		from Location l
		LEFT JOIN Area a ON l.AreaID = a.AreaID 
		LEFT JOIN Country c ON  a.CountryID = c.CountryID 
		LEFT JOIN Region r ON r.RegionID = c.RegionID 
		LEFT JOIN Continent cn ON cn.ContinentID = r.ContinentID  
		where  AreaName = @AreaName and ContinentName =@ContinentName 
				and RegionName = @RegionName and CountryName = @CountryName 
				and LocationName = @LocationName;
		return @ID;
END

GO
-------------------Client Table ----------------------

 CREATE TABLE Client(
	ClientID int,
	ClientCode VARCHAR(255),
	ClientContactName VARCHAR(100),
	ClientLocationID int,
	CONSTRAINT  PK_Client  PRIMARY KEY(ClientID),
	CONSTRAINT  FK_Client_Location  FOREIGN KEY(ClientLocationID) REFERENCES Location(LocationID)
);


GO

INSERT INTO CLient(ClientID,ClientCode,ClientContactName,ClientLocationID)
SELECT distinct Client_ID, Client_Code, Client_ContactName  
		,dbo.getLocationID(Client_Continent,Client_Region,Client_Country,Client_Area,Client_Location)
		 from IPGDataSet 
where Client_ID not in (select ClientID from CLient)

-------------------ClientCampaign Table ----------------------
 CREATE TABLE ClientCampaign(
	ClientCampaignID int Identity ,
	ClientCampaignName VARCHAR(255),
	ManagerID int,
	ProductID int,
	ClientID int,
	StartDate datetime,
	NumberOfWeeks smallint,
	CONSTRAINT  PK_ClientCampaign  PRIMARY KEY(ClientCampaignID),
	CONSTRAINT  FK_ClientCampaign_Employee  FOREIGN KEY(ManagerID) REFERENCES Employee(EmployeeID),
	CONSTRAINT  FK_ClientCampaign_ProductID  FOREIGN KEY(ProductID) REFERENCES Product(ProductID),
	CONSTRAINT  FK_ClientCampaign_ClientID  FOREIGN KEY(ClientID) REFERENCES Client(ClientID)
);
GO

IF OBJECT_ID(N'dbo.getEmployeeID' , 'function') IS NOT NULL 
	DROP FUNCTION getEmployeeID;
GO
CREATE FUNCTION getEmployeeID(@EmployeeName VARCHAR(255))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = EmployeeID from Employee where EmployeeName = @EmployeeName;
	return @ID;
END

GO
IF OBJECT_ID(N'dbo.getCampaignNumberOfWeeks' , 'function') IS NOT NULL 
	DROP FUNCTION getCampaignNumberOfWeeks;
GO
CREATE FUNCTION getCampaignNumberOfWeeks(@ClientCampaignName VARCHAR(255))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = max(cast ( CampaignWeek as int )) from IPGDataSet where DDS_Campaign_Name = @ClientCampaignName;
	return @ID;
END

GO

IF OBJECT_ID(N'dbo.getProductID' , 'function') IS NOT NULL 
	DROP FUNCTION getProductID;
GO
CREATE FUNCTION getProductID(@ProductName VARCHAR(255))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = ProductID from Product where ProductCode = @ProductName;
	return @ID;
END

IF OBJECT_ID(N'dbo.getClientID' , 'function') IS NOT NULL 
	DROP FUNCTION getClientID;
GO
CREATE FUNCTION getClientID(@ClientName VARCHAR(255))
RETURNS int
as
BEGIN
	DECLARE @ID int;
	select @ID = ClientID from Client where ClientCode = @ClientName;
	return @ID;
END

INSERT INTO ClientCampaign(ClientCampaignName,ManagerID,StartDate,NumberOfWeeks,ProductID,ClientID)
SELECT  DDS_Campaign_Name, CampaignManager = dbo.getEmployeeID(Campaign_Manager), 
		Campaign_StartDate, dbo.getCampaignNumberOfWeeks(DDS_Campaign_Name),
		 dbo.getProductID(Client_Product),dbo.getClientID(Client_Code)
from IPGDataSet 
where DDS_Campaign_Name not in (select ClientCampaignName from ClientCampaign)
group by DDS_Campaign_Name, dbo.getEmployeeID(Campaign_Manager),Campaign_StartDate ,dbo.getProductID(Client_Product) ,dbo.getClientID(Client_Code)

-------------------------------------------------------------------
--Note :- need to creat trigger when insert update ClientCampaign
-------------------ClientCampaignPlan Table ----------------------

 CREATE TABLE ClientCampaignPlan(
	ClientCampaignPlanID int Identity ,
	ClientCampaignPlaneDescription VARCHAR(255),
	ClientCampaignID int,
	WeekNumber smallint,
	StratDate datetime,
	EndDate datetime,
	iYear smallint,
	PublisherID int,
	LanguageID int,
	BuyerEmployeeID int,
	LOBID char(3),
	LocationID int,
	BuyingOptionID int,
	PaymentPlanID int,
	CreativeSizeID int,
	Creative varchar(256),
	Placement  varchar(256),
	PlannedAds int,
	RunAds int,
	PlannedSpend float,
	ActualSpend float,
	Impressions int,
	Clickes int,
	CPM float,
	CPC float,
	CTR float,
	Reach int,
	CPR float,
	Frequency float,
	Swipes int,
	Calls float,
	Responses float,
	BounceRate float,
	GPAConversion float,
	CONSTRAINT  PK_ClientCampaignPlan  PRIMARY KEY(ClientCampaignPlanID),
	CONSTRAINT  FK_ClientCampaignPlan_ClientCampaignID  FOREIGN KEY(ClientCampaignID) REFERENCES ClientCampaign(ClientCampaignID),	
	CONSTRAINT  FK_ClientCampaignPlan_PublisherNetwork  FOREIGN KEY(PublisherID) REFERENCES PublisherNetwork(PublisherID),
	CONSTRAINT  FK_ClientCampaignPlan_Language  FOREIGN KEY(LanguageID) REFERENCES CampaignLanguage(LanguageID),
	CONSTRAINT  FK_ClientCampaignPlan_BuyerEmployee  FOREIGN KEY(BuyerEmployeeID) REFERENCES Employee(EmployeeID),
	CONSTRAINT  FK_ClientCampaignPlan_LineOfBusiness  FOREIGN KEY(LOBID) REFERENCES LineOfBusiness(LOBID),
	CONSTRAINT  FK_ClientCampaignPlan_Location  FOREIGN KEY(LocationID) REFERENCES Location(LocationID),
	CONSTRAINT  FK_ClientCampaignPlan_BuyingOption  FOREIGN KEY(BuyingOptionID) REFERENCES BuyingOption(BuyingOptionID),
	CONSTRAINT  FK_ClientCampaignPlan_PaymentPlan  FOREIGN KEY(PaymentPlanID) REFERENCES PaymentPlan(PaymentPlanID),
	CONSTRAINT  FK_ClientCampaignPlan_CreativeSize  FOREIGN KEY(CreativeSizeID) REFERENCES CreativeSize(CreativeSizeID)
);
GO

------------------------------------------------------------------------------------------







		

