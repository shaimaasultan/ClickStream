
IF OBJECT_ID(N'Country' , 'U') IS NOT NULL
	DROP Table Country
Go
/*---------------Create Common Country Table-----------------------*/ 
Create Table Country(ID int identity , CountyCode char(3)  , CountyName varchar(50) , constraint PK_Country Primary key CLUSTERED (ID ASC))
Insert into Country values('USA' , 'U.S.A.'),
						  ('USA' , 'US'),
						  ('CAN','Canada'),
						  ('FRA','France');
GO
/*-----------Add CountryCode Column To Geographics &  SalesPersons----------------*/
if not exists (select  1 from sys.columns c , sys.objects o 
where c.object_id = o.object_id and o.name = N'GeographicLocation' 
and c.name = N'CountryCode')
BEGIN
	Alter table GeographicLocation add CountryCode varchar(4);
END
GO 
if not exists (select  1 from sys.columns c , sys.objects o 
where c.object_id = o.object_id and o.name = N'SalesPersons' 
and c.name = N'CountryCode')
BEGIN
	Alter table SalesPersons add CountryCode varchar(4);
END
GO 
/*-------------------- Country Code -----------------------*/
IF OBJECT_ID(N'dbo.getCountryCode' , 'function') IS NOT NULL
	DROP FUNCTION dbo.getCountryCode
Go
CREATE FUNCTION dbo.getCountryCode(@CountyName varchar(50))
RETURNS varchar(3)
AS
BEGIN
	DECLARE @Code varchar(3);
	SELECT @Code = CountyCode FROM Country WHERE CountyName = @CountyName; 
	RETURN isnull(@Code,substring(@CountyName,1,3));
END
GO
Update SalesPersons set CountryCode = dbo.getCountryCode(Country);

Update GeographicLocation set CountryCode = dbo.getCountryCode(Country);
/*----------------------------------------------------*/
IF OBJECT_ID(N'T_InsertSalesPerson' , 'trigger') IS NOT NULL
	DROP TRIGGER T_InsertSalesPerson
Go
CREATE Trigger T_InsertSalesPerson
on SalesPersons
Instead Of Insert
as
Begin
	insert into SalesPersons
	select * from inserted;
    Update SalesPersons set CountryCode = dbo.getCountryCode(Country);
End 

GO
IF OBJECT_ID(N'T_InsertGeographicLocation' , 'trigger') IS NOT NULL
	DROP TRIGGER T_InsertGeographicLocation
Go
CREATE Trigger T_InsertGeographicLocation
on GeographicLocation
Instead Of Insert
as
Begin
	insert into GeographicLocation (City , Country , Continent)
	select  City , Country , Continent from inserted;
    Update GeographicLocation set CountryCode = dbo.getCountryCode(Country);
End 

GO

/*-------------Add Insted Of insert Trigger -------------------------*/
IF OBJECT_ID(N'T_InsertOrder' , 'trigger') IS NOT NULL
	DROP TRIGGER T_InsertOrder
Go
CREATE Trigger T_InsertOrder
on Orders
Instead Of Insert
as
Begin
    if not exists (select 1 from Customers c , inserted i where c.CustomerID = i.CustomerID)
	insert into Customers (CustomerID,Company , City)
	select i.CustomerID , 'Comp'+cast(i.CustomerID as varchar) , 'City'+ cast(i.CustomerID as varchar)  from inserted i ;

	insert into Orders
	select * from inserted;

End 
/*--------------------Add Foreign Key between Customers and Orders----------*/
 if not exists (select  1 from sys.objects where name = N'FK_Orders_Customers')
BEGIN
	Alter table Orders Add constraint FK_Orders_Customers foreign key (CustomerID) references Customers(CustomerID);
END
/*--------------------Add Foreign Key between Products and Orders----------*/
 if not exists (select  1 from sys.objects where name = N'FK_Orders_Products')
BEGIN
	Alter table Orders Add constraint FK_Orders_Products foreign key (ProductID) references Products(ProductID);
END
/*--------------------Add Foreign Key between Products and Orders----------*/
 if not exists (select  1 from sys.objects where name = N'FK_Orders_Products')
BEGIN
	Alter table Orders Add constraint FK_Orders_Products foreign key (ProductID) references Products(ProductID);
END

/*--------------------Add Primary Key on Customers----------*/
 if not exists (select  1 from sys.objects where name = N'PK_Customers')
BEGIN
	Alter table Customers Add constraint PK_Customers PRIMARY KEY CLUSTERED (CustomerID ASC);
END
/*--------------------Add Primary Key on Products ----------*/
 if not exists (select  1 from sys.objects where name = N'PK_Products')
BEGIN
	Alter table Products Add constraint PK_Products PRIMARY KEY CLUSTERED (ProductID ASC);
END
/*--------------------Add Primary Key on SalesPersons----------*/
 if not exists (select  1 from sys.objects where name = N'PK_SalesPersons')
BEGIN
	Alter table SalesPersons Add constraint PK_SalesPersons PRIMARY KEY CLUSTERED (PersonID ASC);
END
/*--------------------Add Primary Key on Orders----------*/
 if not exists (select  1 from sys.objects where name = N'PK_Orders')
BEGIN
	Alter table Orders Add constraint PK_Orders PRIMARY KEY CLUSTERED (OrderID);
END

/*-------------- Add Identity Key to GeographicLocation Table---------*/
if not exists (select  1 from sys.columns c , sys.objects o 
where c.object_id = o.object_id and o.name = N'GeographicLocation' 
and c.name = N'ID')
	Alter table GeographicLocation add ID int primary key identity;
Go 
/*-------------- create relation between Customers and GeographicLocation Tables---------*/
if not exists (select  1 from sys.columns c , sys.objects o 
where c.object_id = o.object_id and o.name = N'Customers' 
and c.name = N'GeoID')
BEGIN
	Alter table Customers add GeoID int;
	Alter table Customers Add constraint FK_GeoID foreign key (GeoID) references GeographicLocation(ID);
END
Go


