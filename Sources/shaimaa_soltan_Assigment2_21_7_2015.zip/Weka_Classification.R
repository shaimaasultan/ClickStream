# shaimaa Soltan 16-07-2015
# Assign 2 ( Classification) 
#1. Import the data	to R	(no	 cleanup necessary).
#------------------------------------------------
# Please First check your working directory first 
df_train = read.csv(file='pendigits.tra(1).csv',header = F , sep=',')
df_test = read.csv(file='pendigits.tes(1).csv',header = F , sep=',')

class = df_train[17]

#most signofocant feature on Class 0
#installed.packages("corrplot")
#corrplot(cor(df_train), method="ellipse")


#plot data
boxplot( df_train[,11] ~ df_train[,17] , col=rainbow(10),main="V11 in training")
qplot(df_train[,11],fill = as.factor(df_train[,17]) ,data = df_train ,geom=c("density") , alpha=I(.5))
#------------------------------------------------
#2. Use  k	nearest	neighbour	to	predict	the	digit	labels	
# on	the	test	dataset (you may use a library)
#------------------------------------------------
install.packages("RWeka")
install.packages("kknn")
library("RWeka") # rweka (embedded Weka software)
library("kknn") # knn library
attach(df_train)
#-------------------------------------------------
# Utilities :: Weka classifier Summary Data function (WekaAccuracy)
#=========================================================
# how to use Example : 
# WekaAccuracy(df_train,train_Classes = df_train[,17],
#             df_test = df_test, 
#             Actual_test_Classes = df_test[,17],k=100)
WekaAccuracy <- function(df_train , train_Classes,df_test,Actual_test_Classes,k)
{
  #run Weka Classification algorithm  
  classifier <- IBk(as.factor(train_Classes)~., data = df_train, control = Weka_control(K = k ))
  # see how the model correctly predict the data
  Predicted_Classes <- predict(classifier, newdata = df_test,type = c("class"))
  #Predection Classes Table
  conf_Matrix <- table( Actual_test_Classes , Predicted_Classes)
  #number of correct predict = sum(diagonal in conf matrix)
  Correct_Predict <- 0;
  for (i in 1:nrow(conf_Matrix))
  {
    Correct_Predict <- Correct_Predict + conf_Matrix[i,i];
  }
  # number of false predicted = total - correct predected
  False_pred <- nrow(df_test) - Correct_Predict;
  
  Accuracy_Perc <- (Correct_Predict / nrow(df_test) ) * 100;
  Error_Perc <-  (False_pred / nrow(df_test))* 100;
  return ( list("Classifier best K Value "= classifier, "Confusion Matrix" = conf_Matrix,"Correctly Classified %" = Accuracy_Perc,"Worng Classified %" = Error_Perc));
  
}
summary(df_train)
#------------------------------------------------
# Utilities :: normalize vector function
#=========================================
normalize <- function(x)
{
  return ((x - min(x)) / (max(x)-min(x)))
}
#------------------------------------------------
# Utilities :: Weka get best K value
#================================================
WekaSelectBestK <- function(df_train , train_Classes,df_test,Actual_test_Classes)
{
  result<- rbind(data.frame() , c(0,0))
  for ( k in 1:100)
  {
    #run Weka Classification algorithm  
    classifier <- IBk(as.factor(train_Classes)~., data = df_train, control = Weka_control(K = k ))
    # see how the model correctly predict the data
    Predicted_Classes <- predict(classifier, newdata = df_test,type = c("class"))
    #Predection Classes Table
    conf_Matrix <- table(Actual_test_Classes ,Predicted_Classes )
    #number of correct predict = sum(diagonal in conf matrix)
    Correct_Predict <- 0;
    for (i in 1:nrow(conf_Matrix))
    {
      Correct_Predict <- Correct_Predict + conf_Matrix[i,i];
    }
    # number of false predicted = total - correct predected
    False_pred <- nrow(df_test) - Correct_Predict;
    
    Accuracy_Perc <- (Correct_Predict / nrow(df_test) ) * 100;
    result<- rbind(result ,c(k,Accuracy_Perc))
  }
  
  return ( result[result[,2]==max(result[2]) , 1 ]);
  
}
#-------------------------------------------------------------
# Module 1 ) - apply normalization Before apply Weka Classifier
#============================================================
df_train2 <- as.data.frame(lapply(df_train[,-17], normalize))
df_test2 <- as.data.frame(lapply(df_test[,-17], normalize))
df_train2[17] <- df_train[17]
df_test2[17] <- df_test[17]

summary(df)
WekaAccuracy(df_train2,train_Classes = df_train2[,17],
             df_test = df_test2, 
             Actual_test_Classes = df_test2[,17],k=3)
#------------------------------------------------------------
# Module 2 ) - Apply Weka classifier without any normalization
# ============================================================
WekaAccuracy(df_train,train_Classes = df_train[,17],
             df_test = df_test, 
             Actual_test_Classes = df_test[,17],k=3)
#-------------------------------------------------------------
# Module 3 ) - Apply Cross-validation on combined DataSet
#-------------------------------------------------------------
#combine the Two Data Sets
df <- rbind.data.frame(df_train,df_test)
#create weka Classifier
Classifier <- IBk(as.factor(df[,17])~. , data=df, control= Weka_control(K = 3))
#Evalute IBK Classifier using cross validation
evaluate_Weka_classifier(Classifier,numFolds =20,data = df)
#----------------------------------------------------------
#Module 4) - Apply knn from Class package
#==========================================================
#load calss
library(class)
#Apply knn
ml<- knn(train = df_train , test=df_test , cl = df_train[,17],k=3)

#test Performance
conf_Matrix <- table(df_test[,17] , ml)
#number of correct predict = sum(diagonal in conf matrix)
Correct_Predict <- 0;
for (i in 1:nrow(conf_Matrix))
{
  Correct_Predict <- Correct_Predict + conf_Matrix[i,i];
}
# number of false predicted = total - correct predected
False_pred <- nrow(df_test) - Correct_Predict;

Accuracy_Perc <- (Correct_Predict / nrow(df_test) ) * 100;
Error_Perc <-  (False_pred / nrow(df_test))* 100;
#----------------------------------------------------
# Module 5) - Feature reduction
#====================================================
attach(df_test)


classifier <- IBk(as.factor(df_train$V17)~ V1 + V2 + V3 + V4 + V5 + V6 + V7 + V8 + V9 + V10 + V11 + V12 + V13 + V14 + V15 + V16 + V17, data = df_train, control = Weka_control(K=3 ))
# see how the model correctly predict the data
Predicted_Classes <- predict(classifier, newdata = df_test,type = c("class"))
#Predection Classes Table
conf_Matrix <- table( df_test[,17] , Predicted_Classes)
#number of correct predict = sum(diagonal in conf matrix)
Correct_Predict <- 0;
for (i in 1:nrow(conf_Matrix))
{
  Correct_Predict <- Correct_Predict + conf_Matrix[i,i];
}
# number of false predicted = total - correct predected
False_pred <- nrow(df_test) - Correct_Predict;

Accuracy_Perc <- (Correct_Predict / nrow(df_test) ) * 100;
Error_Perc <-  (False_pred / nrow(df_test))* 100;
#-----------------------------------------------
# Module 6) Weighted kNN
#-----------------------------------------------

fit.kknn <- kknn(as.factor(df_train[,17])~ ., df_train, df_test)
table(df_test[,17], fit.kknn$fit)
fit.train1 <- train.kknn(as.factor(df_train[,17]) ~ ., df_train, kmax = 15, 
                          kernel = c("triangular", "rectangular", "epanechnikov", "optimal"), distance = 2)

conf_Matrix <- table(predict(fit.train1, df_test), df_test[,17])
#number of correct predict = sum(diagonal in conf matrix)
Correct_Predict <- 0;
for (i in 1:nrow(conf_Matrix))
{
  Correct_Predict <- Correct_Predict + conf_Matrix[i,i];
}
# number of false predicted = total - correct predected
False_pred <- nrow(df_test) - Correct_Predict;

Accuracy_Perc <- (Correct_Predict / nrow(df_test) ) * 100;
Error_Perc <-  (False_pred / nrow(df_test))* 100;
